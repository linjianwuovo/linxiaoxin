package com.linxin.feature.more.ui

import androidx.compose.ui.res.stringResource
import android.app.AlarmManager
import android.app.NotificationManager
import android.Manifest
import android.content.pm.PackageManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.BatterySaver
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.EventAvailable
import androidx.compose.material.icons.outlined.EventNote
import androidx.compose.material.icons.outlined.Grading
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.outlined.WorkHistory
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Switch
import top.yukonga.miuix.kmp.basic.SwitchDefaults
import top.yukonga.miuix.kmp.basic.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.linxin.R
import com.linxin.core.designsystem.component.LxCard
import com.linxin.core.designsystem.component.LxTopBar
import com.linxin.core.designsystem.theme.LxCream
import com.linxin.core.designsystem.theme.LxInk
import com.linxin.core.designsystem.theme.LxInkGhost
import com.linxin.core.designsystem.theme.LxInkSoft
import com.linxin.core.designsystem.theme.LxSand
import com.linxin.core.designsystem.theme.LxSandDeep

@Composable
fun MoreFeaturesScreen(
    onBack: () -> Unit,
    onNavigateLabor: () -> Unit,
    onNavigateRepair: () -> Unit,
    onNavigateLeave: () -> Unit,
    onNavigateCard: () -> Unit,
    onNavigateExam: () -> Unit,
    onNavigateCredit: () -> Unit,
    onNavigateHoliday: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(MORE_PREFS_NAME, Context.MODE_PRIVATE) }
    var liveNotificationEnabled by remember {
        mutableStateOf(prefs.getBoolean(KEY_LIVE_NOTIFICATION_ENABLED, true))
    }
    var permissionRefreshTick by remember { mutableIntStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permissionRefreshTick++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val exactAlarmGranted = permissionRefreshTick.let { context.canScheduleExactAlarmsCompat() }
    val batteryOptimizationIgnored = permissionRefreshTick.let { context.isIgnoringBatteryOptimizationsCompat() }
    // Android 16 的实况更新（ColorOS 流体云照的就是这套标准 API）。这条得运行时授权，
    // 没授权时 canPostPromotedNotifications() 一直回 false，我们就只能走普通通知，
    // 所以把它做成一行看得见的状态，而不是默默降级。
    val promotedAllowed = permissionRefreshTick.let { context.canPostPromotedCompat() }
    val promotedLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) {
        permissionRefreshTick++
        // 系统要是没弹这一发（权限本来就已经给了、或者这个 ROM 没那套弹层），就地把他送到
        // 应用的通知设置页 —— 那一页上能自己拨实况/流体云那些开关。点了没反应比点了报错更难查。
        if (!context.canPostPromotedCompat()) context.openAppNotificationSettings()
    }

    Scaffold(
        modifier = modifier,
        containerColor = MiuixTheme.colorScheme.background,
        topBar = { LxTopBar(title = stringResource(R.string.title_more_functions), onBack = onBack) },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(horizontal = 20.dp, vertical = 16.dp)) {
            LxCard {
                Column {
                    MoreMenuRow(
                        icon = Icons.Outlined.EventNote,
                        title = stringResource(R.string.title_holiday),
                        onClick = onNavigateHoliday,
                    )
                    MoreMenuDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.WorkHistory,
                        title = stringResource(R.string.title_labor),
                        onClick = onNavigateLabor,
                    )
                    MoreMenuDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.Build,
                        title = stringResource(R.string.title_repair),
                        onClick = onNavigateRepair,
                    )
                    MoreMenuDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.EventAvailable,
                        title = stringResource(R.string.title_leave),
                        onClick = onNavigateLeave,
                    )
                    MoreMenuDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.AccountBalanceWallet,
                        title = stringResource(R.string.title_card),
                        onClick = onNavigateCard,
                    )
                    MoreMenuDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.Grading,
                        title = stringResource(R.string.title_exam),
                        onClick = onNavigateExam,
                    )
                    MoreMenuDivider()
                    MoreMenuRow(
                        icon = Icons.Outlined.EmojiEvents,
                        title = stringResource(R.string.title_credit),
                        onClick = onNavigateCredit,
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            LxCard {
                Column {
                    LiveNotificationRow(
                        enabled = liveNotificationEnabled,
                        onCheckedChange = { enabled ->
                            liveNotificationEnabled = enabled
                            prefs.edit().putBoolean(KEY_LIVE_NOTIFICATION_ENABLED, enabled).apply()
                        },
                    )
                    if (liveNotificationEnabled) {
                        MoreMenuDivider()
                        MoreMenuRow(
                            icon = Icons.Outlined.Alarm,
                            title = stringResource(R.string.more_exact_alarm),
                            trailing = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                if (exactAlarmGranted) stringResource(R.string.more_granted) else stringResource(R.string.more_not_granted)
                            } else {
                                stringResource(R.string.more_not_needed)
                            },
                            trailingColor = if (exactAlarmGranted) LxInkGhost else MiuixTheme.colorScheme.error,
                            onClick = { context.openExactAlarmSettings() },
                        )
                        MoreMenuDivider()
                        MoreMenuRow(
                            icon = Icons.Outlined.BatterySaver,
                            title = stringResource(R.string.more_battery),
                            trailing = if (batteryOptimizationIgnored) stringResource(R.string.more_in_whitelist) else stringResource(R.string.more_not_in_whitelist),
                            trailingColor = if (batteryOptimizationIgnored) LxInkGhost else MiuixTheme.colorScheme.error,
                            onClick = { context.openBatteryOptimizationSettings(batteryOptimizationIgnored) },
                        )
                        MoreMenuDivider()
                        MoreMenuRow(
                            icon = Icons.Outlined.NotificationsActive,
                            title = stringResource(R.string.more_promoted_permission),
                            trailing = when {
                                !context.supportsPromotedCompat() -> stringResource(R.string.more_promoted_unsupported)
                                promotedAllowed -> stringResource(R.string.more_granted)
                                else -> stringResource(R.string.more_not_granted)
                            },
                            trailingColor = if (promotedAllowed || !context.supportsPromotedCompat()) {
                                LxInkGhost
                            } else {
                                MiuixTheme.colorScheme.error
                            },
                            onClick = {
                                if (context.supportsPromotedCompat() && !promotedAllowed) {
                                    promotedLauncher.launch(Manifest.permission.POST_PROMOTED_NOTIFICATIONS)
                                } else {
                                    context.openAppNotificationSettings()
                                }
                            },
                        )
                        MoreMenuDivider()
                        MoreMenuRow(
                            icon = Icons.Outlined.Settings,
                            title = stringResource(R.string.more_fluid_cloud_settings),
                            trailing = stringResource(R.string.more_open_settings),
                            onClick = { context.openAppNotificationSettings() },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveNotificationRow(
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(
            imageVector = Icons.Outlined.NotificationsActive,
            contentDescription = null,
            tint = LxInkSoft,
            modifier = Modifier.size(22.dp),
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.more_live),
                fontSize = 15.sp,
                color = LxInk,
            )
            Text(
                text = stringResource(R.string.more_live_hint),
                modifier = Modifier.padding(top = 4.dp),
                fontSize = 12.sp,
                lineHeight = 16.sp,
                color = LxInkSoft,
            )
        }
        Switch(
            checked = enabled,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.switchColors(
                uncheckedTrackColor = LxSandDeep,
            ),
        )
    }
}

@Composable
private fun MoreMenuRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit,
    trailing: String? = null,
    trailingColor: Color = LxInkGhost,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val bg = if (isPressed) LxCream else Color.Transparent

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bg)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            )
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = LxInkSoft,
            modifier = Modifier.size(22.dp),
        )
        Text(
            text = title,
            fontSize = 15.sp,
            color = LxInk,
            modifier = Modifier.weight(1f),
        )
        if (trailing != null) {
            Text(
                text = trailing,
                fontSize = 13.sp,
                color = trailingColor,
            )
        }
        Text(
            text = "›",
            fontSize = 18.sp,
            fontWeight = FontWeight.Light,
            color = LxInkGhost,
        )
    }
}

@Composable
private fun MoreMenuDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 54.dp, end = 18.dp)
            .height(1.dp)
            .background(LxSand),
    )
}

private const val MORE_PREFS_NAME = "app_prefs"
private const val KEY_LIVE_NOTIFICATION_ENABLED = "live_notification_enabled"

/** 系统有没有这套实况更新能力（Android 16 / API 36 起） */
private fun Context.supportsPromotedCompat(): Boolean = Build.VERSION.SDK_INT >= 36

/**
 * 问系统「这条应用现在能不能发实况更新」。
 *
 * 光信 `canPostPromotedNotifications()` 会出错事：2026-10-14 米11 上 `dumpsys package` 现查
 * `POST_PROMOTED_NOTIFICATIONS: granted=true`，而这个方法照样回 false。于是那一行永远显示"没授权"，
 * 点它就是给一个**已经给了的**权限发申请，系统连弹层都不弹、秒回 —— 他一句「打不开」撞的就是这一下。
 * 所以两个都问：任一为真就算已授权（系统那边自己的总开关仍然可能在关，那是下面「去设置」那一行的事）。
 */
private fun Context.canPostPromotedCompat(): Boolean {
    if (!supportsPromotedCompat()) return false
    val byManager = runCatching {
        getSystemService(NotificationManager::class.java).canPostPromotedNotifications()
    }.getOrDefault(false)
    if (byManager) return true
    return runCatching {
        checkSelfPermission(Manifest.permission.POST_PROMOTED_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)
}

private fun Context.openAppNotificationSettings() {
    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { startActivity(intent) }.onFailure {
        startActivity(
            Intent(Settings.ACTION_ALL_APPS_NOTIFICATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}

private fun Context.canScheduleExactAlarmsCompat(): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
    val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
    return alarmManager.canScheduleExactAlarms()
}

private fun Context.isIgnoringBatteryOptimizationsCompat(): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
    val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
    return powerManager.isIgnoringBatteryOptimizations(packageName)
}

private fun Context.openExactAlarmSettings() {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
    startActivity(
        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
            data = Uri.parse("package:$packageName")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        },
    )
}

private fun Context.openBatteryOptimizationSettings(alreadyIgnored: Boolean) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
    val intent = if (alreadyIgnored) {
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    } else {
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$packageName")
        }
    }
    startActivity(intent.apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
}
