package com.linxin.feature.schedule.ui
import com.linxin.R
import androidx.compose.ui.res.stringResource
import com.linxin.core.designsystem.theme.RLg

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.overlay.OverlayBottomSheet
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.linxin.core.designsystem.component.LxDetailRow
import com.linxin.core.designsystem.component.LxEmpty
import com.linxin.core.designsystem.component.LxError
import com.linxin.core.designsystem.component.LxLoading
import com.linxin.core.designsystem.theme.LxCategoryColors
import com.linxin.core.designsystem.theme.LxInk
import com.linxin.core.designsystem.theme.LxInkMuted
import com.linxin.core.designsystem.theme.LxInkSoft
import com.linxin.core.designsystem.theme.LxTerra
import com.linxin.core.designsystem.theme.LxTerraGlow
import com.linxin.core.domain.SectionSchedule
import com.linxin.feature.schedule.domain.Course
import java.time.LocalDate
import java.time.LocalTime

private const val SECTION_COUNT = 10
private val DAY_LABELS = listOf(R.string.sched_wday_1, R.string.sched_wday_2, R.string.sched_wday_3,
    R.string.sched_wday_4, R.string.sched_wday_5, R.string.sched_wday_6, R.string.sched_wday_7)

/** 星期标签得在组合里取，所以这份表存资源 id 而不是字符串。 */
@Composable
private fun dayLabel(index: Int): String = stringResource(DAY_LABELS[index])
private val CELL_HEIGHT = 58.dp
private val SECTION_LABEL_WIDTH = 46.dp
private val GRID_START_PADDING = 12.dp
private val GRID_END_PADDING = 10.dp

/** 节次时间格式化为 H:mm（如 8:30 / 10:05） */
private fun formatSectionTime(time: LocalTime): String =
    String.format("%d:%02d", time.hour, time.minute)

/** 把“博文楼（A2）502”拆成两行“博文楼\n（A2）502”，窄课程块里也能显示全 */
private fun splitRoom(room: String): String {
    val trimmed = room.trim()
    val m = Regex("^(.+?[楼馆堂])([（(].*)$").find(trimmed) ?: return trimmed
    return "${m.groupValues[1]}\n${m.groupValues[2]}"
}

@Composable
@androidx.compose.runtime.ReadOnlyComposable
private fun courseColor(name: String): Color {
    val index = (name.hashCode() and 0x7FFFFFFF) % LxCategoryColors.size
    return LxCategoryColors[index]
}

@Composable
fun ScheduleScreen(
    modifier: Modifier = Modifier,
    viewModel: ScheduleViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedCourse by remember { mutableStateOf<Course?>(null) }
    val error = uiState.error

    Scaffold(
        modifier = modifier,
        containerColor = MiuixTheme.colorScheme.background,
        // 状态栏由父级 Box 统一处理并消费；底部悬浮玻璃栏自行避让，这里不再加系统栏内边距
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            uiState.weekInfo?.let { info ->
                WeekSelector(
                    totalWeeks = info.totalWeeks,
                    selectedWeek = uiState.selectedWeek,
                    currentWeek = info.currentWeek,
                    onWeekSelected = viewModel::onWeekSelected,
                )
            }

            when {
                uiState.isLoading -> LxLoading()
                error != null -> LxError(
                    message = error,
                    onRetry = viewModel::retry,
                )
                uiState.courses.isEmpty() -> LxEmpty(message = stringResource(R.string.sched_empty))
                else -> ScheduleGrid(
                    courses = uiState.courses,
                    weekDates = uiState.weekDates,
                    showCurrentDayIndicator = uiState.weekInfo?.currentWeek == uiState.selectedWeek,
                    onCourseClick = { selectedCourse = it },
                )
            }
        }
    }

    selectedCourse?.let { course ->
        OverlayBottomSheet(
            show = true,
            onDismissRequest = { selectedCourse = null },
            backgroundColor = MiuixTheme.colorScheme.surface,
            cornerRadius = RLg,
        ) {
            CourseDetail(course = course)
        }
    }
}

// ═══════════════ 周次选择器（三态胶囊） ═══════════════

@Composable
private fun WeekSelector(
    totalWeeks: Int,
    selectedWeek: Int,
    currentWeek: Int,
    onWeekSelected: (Int) -> Unit,
) {
    val listState = rememberLazyListState()
    LaunchedEffect(selectedWeek) {
        val target = (selectedWeek - 2).coerceAtLeast(0)
        listState.animateScrollToItem(target)
    }
    val currentWeekHint by remember(listState, currentWeek) {
        derivedStateOf {
            val visibleItems = listState.layoutInfo.visibleItemsInfo
            if (visibleItems.isEmpty()) return@derivedStateOf null
            val firstVisibleIndex = visibleItems.first().index
            val lastVisibleIndex = visibleItems.last().index
            when {
                currentWeek < firstVisibleIndex -> R.string.sched_week_left to Alignment.TopStart
                currentWeek > lastVisibleIndex -> R.string.sched_week_right to Alignment.TopEnd
                else -> null
            }
        }
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        LazyRow(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            itemsIndexed(List(totalWeeks) { it }) { _, week ->
                WeekChip(
                    label = if (week == 0) stringResource(R.string.sched_prepare) else stringResource(R.string.sched_week_n, week),
                    isSelected = week == selectedWeek,
                    isCurrent = week == currentWeek,
                    onClick = { onWeekSelected(week) },
                )
            }
        }

        currentWeekHint?.let { (labelRes, alignment) ->
            Text(
                text = stringResource(labelRes),
                modifier = Modifier
                    .align(alignment)
                    .offset(y = (-35).dp)
                    .padding(start = 20.dp, end = 20.dp, top = 2.dp),
                fontSize = 12.sp,
                color = LxInkMuted,
            )
        }
    }
}

@Composable
private fun WeekChip(
    label: String,
    isSelected: Boolean,
    isCurrent: Boolean,
    onClick: () -> Unit,
) {
    // 四态组合：default / cur / on / on.cur（选中填充优先，选中时边框 transparent）
    val bg = if (isSelected) LxTerra else Color.Transparent
    val textColor = when {
        // 贴在陶土品牌色块上的前景：Light/Dark 两种主题下品牌色都是暖橙，固定白字对比度最佳
        isSelected -> Color.White
        isCurrent -> LxInkSoft
        else -> LxInkMuted
    }
    val borderColor = when {
        isSelected -> Color.Transparent
        isCurrent -> LxInkMuted
        else -> Color.Transparent
    }
    val weight = if (isCurrent || isSelected) FontWeight.Medium else FontWeight.Normal

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 5.dp),
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = weight,
            color = textColor,
        )
    }
}

// ═══════════════ 课表网格 ═══════════════

@Composable
private fun ScheduleGrid(
    courses: List<Course>,
    weekDates: Map<Int, String>,
    showCurrentDayIndicator: Boolean,
    onCourseClick: (Course) -> Unit,
) {
    val today = remember { LocalDate.now().dayOfWeek.value } // 1=周一
    // 大一大二接口会下发第0节（早自习），存在时网格从第0节起画；大三等无第0节则从第1节起，行为不变
    val firstSection = if (courses.any { it.startSection <= 0 }) 0 else 1
    val rowCount = SECTION_COUNT - firstSection + 1

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = GRID_START_PADDING, end = GRID_END_PADDING, bottom = 104.dp), // 底部悬浮玻璃栏净空
    ) {
        // ── 表头：星期 ──
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.width(SECTION_LABEL_WIDTH))
            DAY_LABELS.forEachIndexed { index, labelRes ->
                val dayIndex = index + 1
                val isToday = showCurrentDayIndicator && dayIndex == today
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = stringResource(labelRes),
                        fontSize = 12.sp,
                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                        color = if (isToday) LxTerra else LxInkMuted,
                    )
                    weekDates[dayIndex]?.let { date ->
                        Text(
                            text = date,
                            fontSize = 10.sp,
                            color = LxInkMuted,
                        )
                    }
                    if (isToday) {
                        Spacer(modifier = Modifier.height(3.dp))
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .clip(CircleShape)
                                .background(LxTerra),
                        )
                    }
                }
            }
        }

        // ── 课程网格 ──
        Row(modifier = Modifier.fillMaxWidth()) {
            // 节次列
            Column(modifier = Modifier.width(SECTION_LABEL_WIDTH)) {
                repeat(rowCount) { row ->
                    val section = firstSection + row
                    val sectionTime = SectionSchedule.sections[section]
                    Column(
                        modifier = Modifier
                            .height(CELL_HEIGHT)
                            .padding(top = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Top,
                    ) {
                        Text(
                            text = if (section == 0) stringResource(R.string.sched_early) else "$section",
                            fontSize = 10.sp,
                            lineHeight = 12.sp,
                            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        )
                        if (sectionTime != null) {
                            Text(
                                text = "${formatSectionTime(sectionTime.start)}-${formatSectionTime(sectionTime.end)}",
                                fontSize = 7.sp,
                                lineHeight = 9.sp,
                                color = LxInkSoft,
                                maxLines = 1,
                            )
                        }
                    }
                }
            }

            // 7 天列
            (1..7).forEach { day ->
                val isToday = showCurrentDayIndicator && day == today
                val dayCourses = courses.filter { it.dayOfWeek == day }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(CELL_HEIGHT * rowCount)
                        .then(
                            if (isToday) Modifier.background(LxTerraGlow) else Modifier
                        ),
                ) {
                    // 课程块（绝对定位）
                    dayCourses.forEach { course ->
                        val top = (course.startSection - firstSection) * CELL_HEIGHT.value
                        val height = (course.endSection - course.startSection + 1) * CELL_HEIGHT.value
                        val color = courseColor(course.name)
                        // 块越高垂直空间越多：高块允许教室多换行以显示完整
                        val spans = course.endSection - course.startSection + 1
                        val nameMaxLines = if (course.room.isNotBlank() && spans < 2) 2 else 3
                        val roomMaxLines = if (spans >= 2) 4 else 2

                        Box(
                            modifier = Modifier
                                .padding(top = top.dp, start = 1.dp, end = 1.dp)
                                .fillMaxWidth()
                                .height(height.dp)
                                .padding(1.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(color)
                                .clickable { onCourseClick(course) }
                                .padding(horizontal = 2.dp, vertical = 4.dp),
                            contentAlignment = Alignment.TopStart,
                        ) {
                            Column {
                                Text(
                                    text = course.name,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    lineHeight = 12.5.sp,
                                    // 贴在课程块分类色底上的前景固定白字，不随主题变
                                    color = Color.White,
                                    maxLines = nameMaxLines,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                if (course.room.isNotBlank()) {
                                    Text(
                                        text = splitRoom(course.room),
                                        fontSize = 7.sp,
                                        lineHeight = 9.sp,
                                        color = Color.White.copy(alpha = 0.7f),
                                        maxLines = roomMaxLines,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(top = 1.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════ 课程详情 ═══════════════

@Composable
private fun CourseDetail(course: Course) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .padding(bottom = 32.dp),
    ) {
        Text(
            text = course.name,
            style = MiuixTheme.textStyles.title2, // 24sp，全站 MiSans
            color = LxInk,
        )

        Spacer(modifier = Modifier.height(16.dp))

        LxDetailRow(
            label = stringResource(R.string.sched_time),
            value = stringResource(R.string.sched_time_value, dayLabel(course.dayOfWeek - 1), course.startSection, course.endSection),
            labelWidth = 48.dp,
            showDivider = false,
        )

        if (course.room.isNotBlank()) {
            LxDetailRow(label = stringResource(R.string.sched_room), value = course.room, labelWidth = 48.dp, showDivider = false)
        }

        if (course.teacher.isNotBlank()) {
            LxDetailRow(label = stringResource(R.string.sched_teacher), value = course.teacher, labelWidth = 48.dp, showDivider = false)
        }
    }
}
