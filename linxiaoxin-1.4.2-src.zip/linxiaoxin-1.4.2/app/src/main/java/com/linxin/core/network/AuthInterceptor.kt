package com.linxin.core.network

import com.linxin.core.auth.TokenManager
import kotlinx.coroutines.runBlocking
import okhttp3.FormBody
import okhttp3.Interceptor
import okhttp3.Response
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 根据请求域名自动注入对应的认证参数。
 *
 * - 主站 (in.aiit.edu.cn): Form表单追加通用认证参数
 * - 查寝 (fdygl.aiit.edu.cn): JSON body，不由Interceptor注入（在Api层处理）
 * - 运动 (sports.aiit.edu.cn): studentCode header
 * - 劳动 (ldjy.aiit.edu.cn): Form表单追加 userCode/accessToken
 */
@Singleton
class AuthInterceptor @Inject constructor(
    private val tokenManager: TokenManager,
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val host = original.url.host
        val path = original.url.encodedPath

        val request = when {
            // 登录接口不需要注入认证参数
            path.contains("getToken.do") || path.contains("refresh.do") -> original

            // 运动接口: header注入 studentCode
            host.contains("sports.aiit.edu.cn") -> {
                val credentials = runBlocking { tokenManager.snapshot() }
                val token = credentials.accessToken.orEmpty()
                val userCode = credentials.userCode.orEmpty()
                val userType = credentials.userType ?: "1"
                original.newBuilder()
                    .header("studentCode", userCode)
                    .header("accessToken", token)
                    .header("access_token", token)
                    .header("userCode", userCode)
                    .header("xh", userCode)
                    .header("_userCode", userCode)
                    .header("_userType", userType)
                    .header("X-Requested-With", "XMLHttpRequest")
                    .header("Origin", "http://sports.aiit.edu.cn:8082")
                    .header("Referer", "http://sports.aiit.edu.cn:8082/dist/")
                    .build()
            }

            // 查寝接口: H5 实际请求会携带 accessToken/userCode/userType/xh 等身份头
            host.contains("fdygl.aiit.edu.cn") -> {
                val credentials = runBlocking { tokenManager.snapshot() }
                val token = credentials.accessToken.orEmpty()
                val userCode = credentials.userCode.orEmpty()
                val userType = credentials.userType ?: "1"
                original.newBuilder()
                    .header("Authorization", "Bearer $token")
                    .header("accessToken", token)
                    .header("access_token", token)
                    .header("userCode", userCode)
                    .header("xh", userCode)
                    .header("userType", userType)
                    .header("X-Requested-With", "XMLHttpRequest")
                    .header("Origin", "https://fdygl.aiit.edu.cn")
                    .header("Referer", "https://fdygl.aiit.edu.cn/swp-app/")
                    .build()
            }

            // 报修平台: 它 H5 的 body 里只有 accessToken/userName/xh/userType 四个身份字段
            // （读它 dist-app 的 JS 确认：post() 把全局 userInfo 并进每个请求），
            // 这四个由 RepairApi 自己显式声明。这里再注入门户那套就不是照原样发了。
            host.contains("repair.aiit.edu.cn") -> original

            // 业务流转引擎（请假）: 它 H5 的 post() 只并 accessToken/_userCode/_userType/userCode/xh
            // 这五个，读它 app.js 确认；门户那套 access_token/userId/appId 一律不带
            host.contains("ywlz.aiit.edu.cn") -> original

            // 一卡通: 身份在 light.action → redirect.action → authorize 那条链换出来的 cookie 里，
            // bootcallback 的 body 只有 gotowhere 和业务参数，多塞任何字段都不是原样
            host.contains("17wanxiao.com") -> original

            // 主站 & 劳动教育: Form表单追加通用参数
            else -> {
                val credentials = runBlocking { tokenManager.snapshot() }
                val token = credentials.accessToken.orEmpty()
                val userCode = credentials.userCode.orEmpty()
                val userName = credentials.userName.orEmpty()
                val userType = credentials.userType ?: "1"
                val encodedName = URLEncoder.encode(userName, "UTF-8")

                val body = original.body
                if (body is FormBody) {
                    val newBody = FormBody.Builder()
                    for (i in 0 until body.size) {
                        newBody.add(body.name(i), body.value(i))
                    }
                    newBody.add("access_token", token)
                    newBody.add("_userCode", userCode)
                    newBody.add("userId", userCode)
                    newBody.add("_userName", encodedName)
                    newBody.add("_userType", userType)
                    newBody.add("appId", ApiConstants.APP_ID)

                    // 劳动教育额外字段
                    if (host.contains("ldjy.aiit.edu.cn")) {
                        newBody.add("userCode", userCode)
                        newBody.add("xh", userCode)
                        newBody.add("userName", userName)
                        newBody.add("accessToken", token)
                    }

                    original.newBuilder().post(newBody.build()).build()
                } else {
                    original
                }
            }
        }

        return chain.proceed(request)
    }
}
